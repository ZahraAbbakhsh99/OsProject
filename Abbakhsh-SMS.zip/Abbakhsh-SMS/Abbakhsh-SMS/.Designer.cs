﻿namespace Abbakhsh_SMS
{
    partial class AddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.EmpID = new System.Windows.Forms.TextBox();
            this.EmpName = new System.Windows.Forms.TextBox();
            this.EmpLName = new System.Windows.Forms.TextBox();
            this.EmpwExp = new System.Windows.Forms.TextBox();
            this.NumChild = new System.Windows.Forms.TextBox();
            this.Home = new System.Windows.Forms.Button();
            this.Main = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.AssociatWithDepartment = new System.Windows.Forms.Button();
            this.MaritalStatus = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(390, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please complete the form below.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(36, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Employee ID";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(36, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "     Nmae       ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(36, 201);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 22);
            this.label4.TabIndex = 3;
            this.label4.Text = "  Last Name  ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(36, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 22);
            this.label5.TabIndex = 4;
            this.label5.Text = "WExperience";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(36, 310);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 22);
            this.label6.TabIndex = 5;
            this.label6.Text = "NumChildren";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(36, 358);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 22);
            this.label7.TabIndex = 6;
            this.label7.Text = "Marital Status";
            // 
            // EmpID
            // 
            this.EmpID.Location = new System.Drawing.Point(194, 88);
            this.EmpID.Name = "EmpID";
            this.EmpID.Size = new System.Drawing.Size(220, 22);
            this.EmpID.TabIndex = 7;
            // 
            // EmpName
            // 
            this.EmpName.Location = new System.Drawing.Point(194, 144);
            this.EmpName.Name = "EmpName";
            this.EmpName.Size = new System.Drawing.Size(220, 22);
            this.EmpName.TabIndex = 8;
            // 
            // EmpLName
            // 
            this.EmpLName.Location = new System.Drawing.Point(194, 202);
            this.EmpLName.Name = "EmpLName";
            this.EmpLName.Size = new System.Drawing.Size(220, 22);
            this.EmpLName.TabIndex = 9;
            // 
            // EmpwExp
            // 
            this.EmpwExp.Location = new System.Drawing.Point(194, 256);
            this.EmpwExp.Name = "EmpwExp";
            this.EmpwExp.Size = new System.Drawing.Size(220, 22);
            this.EmpwExp.TabIndex = 10;
            // 
            // NumChild
            // 
            this.NumChild.Location = new System.Drawing.Point(194, 311);
            this.NumChild.Name = "NumChild";
            this.NumChild.Size = new System.Drawing.Size(220, 22);
            this.NumChild.TabIndex = 11;
            // 
            // Home
            // 
            this.Home.BackColor = System.Drawing.Color.LightSlateGray;
            this.Home.Location = new System.Drawing.Point(326, 410);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(76, 28);
            this.Home.TabIndex = 14;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = false;
            // 
            // Main
            // 
            this.Main.BackColor = System.Drawing.Color.LightSlateGray;
            this.Main.Location = new System.Drawing.Point(18, 410);
            this.Main.Name = "Main";
            this.Main.Size = new System.Drawing.Size(76, 28);
            this.Main.TabIndex = 15;
            this.Main.Text = "Main";
            this.Main.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Abbakhsh_SMS.Properties.Resources.emp3_1;
            this.pictureBox1.Location = new System.Drawing.Point(438, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(336, 393);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // AssociatWithDepartment
            // 
            this.AssociatWithDepartment.BackColor = System.Drawing.Color.LightSlateGray;
            this.AssociatWithDepartment.Location = new System.Drawing.Point(112, 410);
            this.AssociatWithDepartment.Name = "AssociatWithDepartment";
            this.AssociatWithDepartment.Size = new System.Drawing.Size(199, 28);
            this.AssociatWithDepartment.TabIndex = 18;
            this.AssociatWithDepartment.Text = "Associate With Department";
            this.AssociatWithDepartment.UseVisualStyleBackColor = false;
            // 
            // MaritalStatus
            // 
            this.MaritalStatus.FormattingEnabled = true;
            this.MaritalStatus.Location = new System.Drawing.Point(194, 358);
            this.MaritalStatus.Name = "MaritalStatus";
            this.MaritalStatus.Size = new System.Drawing.Size(219, 24);
            this.MaritalStatus.TabIndex = 19;
            // 
            // AddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MaritalStatus);
            this.Controls.Add(this.AssociatWithDepartment);
            this.Controls.Add(this.Main);
            this.Controls.Add(this.Home);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.NumChild);
            this.Controls.Add(this.EmpwExp);
            this.Controls.Add(this.EmpLName);
            this.Controls.Add(this.EmpName);
            this.Controls.Add(this.EmpID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AddEmployee";
            this.Text = "Add Employee";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox EmpID;
        private System.Windows.Forms.TextBox EmpName;
        private System.Windows.Forms.TextBox EmpLName;
        private System.Windows.Forms.TextBox EmpwExp;
        private System.Windows.Forms.TextBox NumChild;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button Main;
        private System.Windows.Forms.Button AssociatWithDepartment;
        private System.Windows.Forms.ComboBox MaritalStatus;
    }
}