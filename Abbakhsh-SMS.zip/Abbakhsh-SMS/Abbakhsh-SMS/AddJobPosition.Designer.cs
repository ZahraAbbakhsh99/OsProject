﻿namespace Abbakhsh_SMS
{
    partial class AddJobPosition
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.WHW = new System.Windows.Forms.TextBox();
            this.PositionName = new System.Windows.Forms.TextBox();
            this.PositionID = new System.Windows.Forms.TextBox();
            this.Home = new System.Windows.Forms.Button();
            this.Main = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.AssociateWithEmployee = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(24, 212);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Position Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(22, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(390, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "Please complete the form below.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.Location = new System.Drawing.Point(24, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 22);
            this.label3.TabIndex = 3;
            this.label3.Text = "Position ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(24, 285);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(175, 22);
            this.label4.TabIndex = 4;
            this.label4.Text = "Wages for hard work";
            // 
            // WHW
            // 
            this.WHW.Location = new System.Drawing.Point(249, 285);
            this.WHW.Name = "WHW";
            this.WHW.Size = new System.Drawing.Size(214, 22);
            this.WHW.TabIndex = 10;
            // 
            // PositionName
            // 
            this.PositionName.Location = new System.Drawing.Point(212, 213);
            this.PositionName.Name = "PositionName";
            this.PositionName.Size = new System.Drawing.Size(220, 22);
            this.PositionName.TabIndex = 11;
            // 
            // PositionID
            // 
            this.PositionID.Location = new System.Drawing.Point(169, 131);
            this.PositionID.Name = "PositionID";
            this.PositionID.Size = new System.Drawing.Size(220, 22);
            this.PositionID.TabIndex = 12;
            // 
            // Home
            // 
            this.Home.BackColor = System.Drawing.Color.LightSlateGray;
            this.Home.Location = new System.Drawing.Point(371, 395);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(76, 28);
            this.Home.TabIndex = 16;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = false;
            // 
            // Main
            // 
            this.Main.BackColor = System.Drawing.Color.LightSlateGray;
            this.Main.Location = new System.Drawing.Point(28, 395);
            this.Main.Name = "Main";
            this.Main.Size = new System.Drawing.Size(76, 28);
            this.Main.TabIndex = 17;
            this.Main.Text = "Main";
            this.Main.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Abbakhsh_SMS.Properties.Resources.emps4;
            this.pictureBox1.Location = new System.Drawing.Point(477, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(330, 396);
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // AssociateWithEmployee
            // 
            this.AssociateWithEmployee.BackColor = System.Drawing.Color.LightSlateGray;
            this.AssociateWithEmployee.Location = new System.Drawing.Point(131, 395);
            this.AssociateWithEmployee.Name = "AssociateWithEmployee";
            this.AssociateWithEmployee.Size = new System.Drawing.Size(220, 28);
            this.AssociateWithEmployee.TabIndex = 19;
            this.AssociateWithEmployee.Text = "Associate With Employee";
            this.AssociateWithEmployee.UseVisualStyleBackColor = false;
            // 
            // AddJobPosition
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.AssociateWithEmployee);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Main);
            this.Controls.Add(this.Home);
            this.Controls.Add(this.PositionID);
            this.Controls.Add(this.PositionName);
            this.Controls.Add(this.WHW);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AddJobPosition";
            this.Text = "Add Job Position";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox WHW;
        private System.Windows.Forms.TextBox PositionName;
        private System.Windows.Forms.TextBox PositionID;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button Main;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button AssociateWithEmployee;
    }
}