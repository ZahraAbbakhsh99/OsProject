﻿CREATE TABLE Employee
(
	[ID] INT NOT NULL PRIMARY KEY, 
    [Name] NVARCHAR(50) NULL, 
    [LName] NVARCHAR(50) NULL, 
    [WExperienceYear] INT NULL, 
    [NumChild] INT NULL, 
    [MaritalStatus] NCHAR(10) NULL

)
